<?php
return array(
	'time'=>'时间',
	'so_so'=>'搜索',
	'goods_num'=>'商品数量',
	'sell_point'=>'消费积分',
	);
?>